
package com.LaComisaria.pedido.model;

// Importaciones necesarias para las anotaciones de JPA y Lombok

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

// Anotación que indica que esta clase es una entidad JPA
@Entity

// Anotación de Lombok que genera automáticamente los métodos getter, setter, equals, hashCode y toString
@Data


public class categorias {
    // Anotación que indica que este campo es la clave primaria de la entidad
    @Id
    
    // Anotación que indica que este campo debe ser mapeado a una columna de la base de datos
    @Column
    private int idCategoria;
    
    @Column
    private String nombre;
    
    @Column
    private String descripcion;
    
}