
package com.LaComisaria.pedido.model;

//

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class empleado {
    @Id
    @Column
    private int idempleado;
    
    @Column
    private String cargo;
    
    @Column
    private int telefono;
    
}
