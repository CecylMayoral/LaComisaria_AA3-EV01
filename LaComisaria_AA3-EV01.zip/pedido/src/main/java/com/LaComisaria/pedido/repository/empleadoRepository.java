
package com.LaComisaria.pedido.repository;

import com.LaComisaria.pedido.model.empleado;
import org.springframework.data.jpa.repository.JpaRepository;

public interface empleadoRepository extends JpaRepository<empleado, Integer>{
    
}
