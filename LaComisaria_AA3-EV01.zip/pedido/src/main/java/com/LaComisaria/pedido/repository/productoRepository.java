
package com.LaComisaria.pedido.repository;

//

import com.LaComisaria.pedido.model.producto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface productoRepository extends JpaRepository<producto, Integer> {
    
}
