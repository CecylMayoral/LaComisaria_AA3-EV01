
package com.LaComisaria.pedido.service;

import com.LaComisaria.pedido.model.empleado;
import com.LaComisaria.pedido.repository.empleadoRepository;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class empleadoServiceImplement implements empleadoService {
    
    @Autowired
    private empleadoRepository empleadoRepository;

    @Override
    public empleado Newempleado(empleado Newempleado) {
        return empleadoRepository.save(Newempleado);
    }

    @Override
    public Iterable<empleado> getAll() {
        return this.empleadoRepository.findAll();  
    }

    @Override
    public empleado modifyempleado(empleado empleado) {
        Optional<empleado> empleadoEncontrado = this.empleadoRepository.findById(empleado.getIdempleado());
        if (empleadoEncontrado.get()!= null) {
            empleadoEncontrado.get().setCargo(empleado.getCargo());
            empleadoEncontrado.get().setTelefono(empleado.getTelefono());
            return this.Newempleado(empleadoEncontrado.get());
    }
        return null;
    }

    @Override
    public Boolean deleteempleado(Integer idempleado) {
        this.empleadoRepository.deleteById(idempleado);
        return true;
    }
    
}
