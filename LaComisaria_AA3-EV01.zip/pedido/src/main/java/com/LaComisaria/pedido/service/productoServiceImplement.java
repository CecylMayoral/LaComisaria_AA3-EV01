
package com.LaComisaria.pedido.service;

import com.LaComisaria.pedido.model.producto;
import com.LaComisaria.pedido.repository.productoRepository;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class productoServiceImplement implements productoService {

    @Autowired
    private productoRepository productoRepository;
    
    
    @Override
    public producto Newproducto(producto Newproducto) {
        return productoRepository.save(Newproducto);
    }

    @Override
    public Iterable<producto> getAll() {
        return this.productoRepository.findAll();   
    }

    @Override
    public producto modifyproducto(producto producto) {
        Optional<producto> productoEncontrado = this.productoRepository.findById(producto.getId_producto());
        if (productoEncontrado.get()!= null) {
            productoEncontrado.get().setNombre(producto.getNombre());
            productoEncontrado.get().setPrecio(producto.getPrecio());
            productoEncontrado.get().setUnit(producto.getUnit());
            productoEncontrado.get().setCategorias_idCategoria(producto.getCategorias_idCategoria());
            return this.Newproducto(productoEncontrado.get());
    }
        return null;
    }

    @Override
    public Boolean deleteproducto(Integer id_producto) {
        this.productoRepository.deleteById(id_producto);
        return true;
    }
    
}
